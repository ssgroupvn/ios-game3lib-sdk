//
//  G3AWebView.h
//  Game5Connector
//
//  Created by ssg on 7/14/14.
//  Copyright (c) 2014 SSGroup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface G3AWebView : UIView
{
    
}
- (id)initWithFrame:(CGRect)frame withURL:(NSString *)url;
@end
