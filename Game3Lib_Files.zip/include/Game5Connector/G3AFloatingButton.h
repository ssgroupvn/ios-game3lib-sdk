//
//  G3AFloatingButton.h
//  DEMO
//
//  Created by ssg on 6/16/14.
//  Copyright (c) 2014 hexc. All rights reserved.
//

#import "HEXCMyUIButton.h"

@interface G3AFloatingButton : HEXCMyUIButton
{
    
}

- (void) remove;

@end
