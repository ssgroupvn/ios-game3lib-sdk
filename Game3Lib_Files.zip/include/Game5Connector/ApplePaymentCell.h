//
//  ApplePaymentCell.h
//  Game5Connector
//
//  Created by ssg on 4/19/14.
//  Copyright (c) 2014 SSGroup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplePaymentCell : UITableViewCell

@end
