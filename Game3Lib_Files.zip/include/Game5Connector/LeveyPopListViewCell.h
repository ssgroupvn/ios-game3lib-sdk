//
//  LeveyPopListViewCell.h
//  LeveyPopListViewDemo
//
//  Created by Levey on 2/21/12.
//  Copyright (c) 2012 Levey. All rights reserved.
//
#import <UIKit/UIKit.h>


@interface LeveyPopListViewCell : UITableViewCell

@end
