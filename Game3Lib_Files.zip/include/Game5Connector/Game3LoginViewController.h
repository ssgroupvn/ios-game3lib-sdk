//
//  Game5LoginViewController.h
//  testLib
//
//  Created by ssg on 12/10/13.
//  Copyright (c) 2013 xXx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Game5UserData.h"

@interface Game5LoginViewController : UIViewController<UIWebViewDelegate>
{
    UIWebView *webview;
}

@end
